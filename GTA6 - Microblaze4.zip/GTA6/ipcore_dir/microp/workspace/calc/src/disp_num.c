#include <stdio.h>
#include "platform.h"
#include "xparameters.h" // add
#include "xiomodule.h" // add

int bcd_7seg(u32 data, XIOModule gpo);

int main(){
    init_platform(); 
	u32 data=0, disp, cont=0;
	XIOModule gpi;
	XIOModule gpo;
	XIOModule_Initialize(&gpi, XPAR_IOMODULE_0_DEVICE_ID);
	XIOModule_Start(&gpi);
	XIOModule_Initialize(&gpo, XPAR_IOMODULE_0_DEVICE_ID);
	XIOModule_Start(&gpo);
	while (1){
		data = XIOModule_DiscreteRead(&gpi, 1); // read switches (channel 1)
		switch(cont){
			case 0: disp=0b1110;
					data = 0;
			break;
			case 1: disp=0b1101;
					data=1;
			break;
			case 2: disp=0b1011;
					data=2;
			break;
			case 3: disp=0b0111;
					data=3;
			break;
		}
		XIOModule_DiscreteWrite(&gpo, 3, disp);
		bcd_7seg(data,gpo);
	}
	cleanup_platform();
	return 0;
}
