#include <stdio.h>
#include "platform.h"
#include "xparameters.h" // add
#include "xiomodule.h" // add

int disp_num(unsigned int num, XIOModule gpo);

int main(){
    init_platform();
	u32 data=0;
	XIOModule gpi;
	XIOModule gpo;
	XIOModule_Initialize(&gpi, XPAR_IOMODULE_0_DEVICE_ID);
	XIOModule_Start(&gpi);
	XIOModule_Initialize(&gpo, XPAR_IOMODULE_0_DEVICE_ID);
	XIOModule_Start(&gpo);
	while (1){
		data = XIOModule_DiscreteRead(&gpi, 1); // read switches (channel 1)
		disp_num(data, gpo);
	}
	cleanup_platform();
	return 0;
}
