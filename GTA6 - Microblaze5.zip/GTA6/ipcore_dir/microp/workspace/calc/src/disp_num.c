#include <stdio.h>
#include "platform.h"
#include "xparameters.h" // add
#include "xiomodule.h" // add

int bcd_7seg(u32 data, XIOModule gpo);

int disp_num(unsigned int num, XIOModule gpo){
	u32 data, disp;
	unsigned char cont = 0;
	unsigned long int t;
	num=9876;
	//data = XIOModule_DiscreteRead(&gpi, 1); // read switches (channel 1)
	switch(cont){
		case 0: disp=0b1110; //milhar
				data=0;//num/1000;
		break;
		case 1: disp=0b1101; //centena
				data=1;//(num%1000)/100;
		break;
		case 2: disp=0b1011; //dezena
				data=((num%1000)%100)/10;
		break;
		case 3: disp=0b0111; //unidade
				data=((num%1000)%100)%10;
		break;
	}
	XIOModule_DiscreteWrite(&gpo, 3, disp);
	bcd_7seg(data,gpo);
	while(t<10000)
		t++;
	t=0;
	cont++;
	return 0;
}
