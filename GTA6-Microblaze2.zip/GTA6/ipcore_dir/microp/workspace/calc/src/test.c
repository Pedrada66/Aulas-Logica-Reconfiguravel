#include <stdio.h>
#include "platform.h"
#include "xparameters.h" // add
#include "xiomodule.h" // add
int teste()
{
init_platform();
u32 data;
XIOModule gpi;
XIOModule gpo;
XIOModule_Initialize(&gpi, XPAR_IOMODULE_0_DEVICE_ID);
XIOModule_Start(&gpi);
XIOModule_Initialize(&gpo, XPAR_IOMODULE_0_DEVICE_ID);
XIOModule_Start(&gpo);
while (1)
{
data = XIOModule_DiscreteRead(&gpi, 1); // read switches (channel 1)
XIOModule_DiscreteWrite(&gpo, 1, data); // turn on LEDs (channel 1)
}
cleanup_platform();
return 0;
}
