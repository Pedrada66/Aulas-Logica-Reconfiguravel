#include <stdio.h>
#include "platform.h"
#include "xparameters.h" // add
#include "xiomodule.h" // add

int bcd_7seg(u32 data, XIOModule gpo){
	u32 seg;

	switch(data){
		case 0: seg=0b0000001;
		break;
		case 1: seg=0b1001111;
		break;
		case 2: seg=0b0010010;
		break;
		case 3: seg=0b0000110;
		break;
		case 4: seg=0b1001100;
		break;
		case 5: seg=0b0100100;
		break;
		case 6: seg=0b0100000;
		break;
		case 7: seg=0b0001111;
		break;
		case 8: seg=0b0000000;
		break;
		case 9: seg=0b0000100;
		break;
		case 0xA: seg=0b0001000;
		break;
		case 0xB: seg=0b1100000;
		break;
		case 0xC: seg=0b0110001;
		break;
		case 0xD: seg=0b1000010;
		break;
		case 0xE: seg=0b0000001;
		break;
		case 0xF: seg=0b0000001;
		break;
		default: seg=0b1111111;
	}

	XIOModule_DiscreteWrite(&gpo, 2, seg);

	return 0;
}
